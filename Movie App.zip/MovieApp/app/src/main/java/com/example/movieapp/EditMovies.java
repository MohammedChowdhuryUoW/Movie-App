package com.example.movieapp;

import androidx.appcompat.app.AppCompatActivity;

public class EditMovies extends AppCompatActivity {
}
