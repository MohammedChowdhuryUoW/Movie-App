package com.example.movieapp;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ComponentActivity;

public class DisplayedInfo extends AppCompatActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_displayedinfo);
        // Display on the screen
   //     TextView text = (TextView) findViewById(R.id.textView2);
     //   Database databaseInstance = new Database(this);

      //  text.setText(databaseInstance.showMovies(databaseInstance.getMovies()));




    }
}
