package com.example.movieapp;

import androidx.appcompat.app.AppCompatActivity;

public class Ratings extends AppCompatActivity {
}
