package com.example.movieapp;

import androidx.appcompat.app.AppCompatActivity;

public class Search extends AppCompatActivity {
}
